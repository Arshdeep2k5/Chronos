/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { ChronosDatabase } from './src/data/mockDB.js';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize the local-first mock SQLite database
const db = new ChronosDatabase();

// Keep track of simulated current time (starts at June 23, 2026, 10:15 AM)
let simulatedCurrentTime = '2026-06-23T10:15:00-07:00';

// Initialize Gemini client lazily
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
      aiClient = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return aiClient;
}

// --- API ROUTES ---

// 1. Get system information and current simulation time
app.get('/api/system-status', (req, res) => {
  const hasApiKey = !!process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY';
  res.json({
    status: 'ONLINE',
    systemTime: simulatedCurrentTime,
    hasApiKey,
    databaseDiskSizeKb: Math.round(JSON.stringify(db).length / 1024),
    privacyMode: 'LOCAL_ONLY_ZERO_CLOUD'
  });
});

// 2. Get list of all projects and their states
app.get('/api/projects', (req, res) => {
  const projectsWithState = db.projects.map(project => {
    const state = db.projectState.find(s => s.project_id === project.id);
    const commitments = db.commitments.filter(c => c.project_id === project.id);
    const deadlines = db.projectDeadlines.filter(d => d.project_id === project.id);
    const actions = db.projectActions.filter(a => a.project_id === project.id);
    const checkpoint = db.projectCheckpoints
      .filter(c => c.project_id === project.id)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];

    return {
      ...project,
      state,
      commitmentsCount: commitments.length,
      deadlines,
      actionsCount: actions.length,
      latestCheckpoint: checkpoint || null
    };
  });
  res.json(projectsWithState);
});

// 3. Get commitments with Health, Risk, and Completion Projections computed dynamically
app.get('/api/commitments', (req, res) => {
  const commitmentsWithCalculations = db.commitments.map(commitment => {
    const health = db.getCommitmentHealth(commitment, simulatedCurrentTime);
    const calculations = db.getCommitmentRisk(commitment, simulatedCurrentTime);

    return {
      ...commitment,
      health,
      ...calculations
    };
  });
  res.json(commitmentsWithCalculations);
});

// 4. Get uncompleted and prioritized project actions
app.get('/api/actions', (req, res) => {
  const actions = db.computeActionPriorities(simulatedCurrentTime);
  res.json(actions);
});

// 5. Submit a new human ground-truth checkpoint
app.post('/api/checkpoints', (req, res) => {
  const { project_id, accomplished_text, blocked_text, next_steps_text } = req.body;
  if (!project_id || !accomplished_text) {
    return res.status(400).json({ error: 'project_id and accomplished_text are required.' });
  }

  const newCheckpoint = {
    id: db.projectCheckpoints.length + 1,
    project_id: parseInt(project_id),
    accomplished_text,
    blocked_text: blocked_text || '',
    next_steps_text: next_steps_text || '',
    created_at: simulatedCurrentTime
  };

  db.projectCheckpoints.push(newCheckpoint);

  // When a human checkpoint is submitted, automatically trigger an Attention Weight (W_attn) boost:
  // Explicitly reference nodes or tasks in project state
  const projectState = db.projectState.find(s => s.project_id === parseInt(project_id));
  if (projectState) {
    projectState.next_action = next_steps_text || projectState.next_action;
    projectState.updated_at = simulatedCurrentTime;
  }

  // Also seed a context event indicating the user created/opened a checkpoint
  const nodeId = parseInt(project_id) === 1 ? 2 : 6; // default nodes
  db.contextEvents.push({
    id: db.contextEvents.length + 1,
    node_id: nodeId,
    event_type: 'REFERENCED',
    interaction_duration: 300,
    captured_at: simulatedCurrentTime
  });

  db.save();
  res.json({ success: true, checkpoint: newCheckpoint });
});

// 6. Toggle Action Status (Completed / Pending)
app.post('/api/actions/toggle', (req, res) => {
  const { action_id } = req.body;
  const action = db.projectActions.find(a => a.id === parseInt(action_id));
  if (!action) {
    return res.status(404).json({ error: 'Action not found.' });
  }

  action.status = action.status === 'COMPLETED' ? 'PENDING' : 'COMPLETED';
  db.save();
  res.json({ success: true, action });
});

// 7. Time Travel Simulation (Demonstrating Failure Projections)
app.post('/api/time-travel', (req, res) => {
  const { hours } = req.body;
  if (!hours) {
    return res.status(400).json({ error: 'hours is required.' });
  }

  const currentTimeMs = new Date(simulatedCurrentTime).getTime();
  const timeTravelMs = parseInt(hours) * 60 * 60 * 1000;
  
  // Fast forward the simulated current clock
  simulatedCurrentTime = new Date(currentTimeMs + timeTravelMs).toISOString();

  // Also simulate time passing with no edits or project events (Attention decay)
  // Which drops recent focus weights, triggering Commitment amber/red risk states!
  res.json({
    success: true,
    newTime: simulatedCurrentTime,
    message: `Time-traveled forward ${hours} hours. Workspace focus weights decayed, recalculating failure risks...`
  });
});

// 8. Generate Recovery Plan using Gemini API
app.post('/api/generate-plan', async (req, res) => {
  const { commitment_id } = req.body;
  const commitment = db.commitments.find(c => c.id === parseInt(commitment_id));
  if (!commitment) {
    return res.status(404).json({ error: 'Commitment not found.' });
  }

  const project = db.projects.find(p => p.id === commitment.project_id);
  const actions = db.projectActions.filter(a => a.project_id === commitment.project_id && a.status === 'PENDING');
  const latestCheckpoint = db.projectCheckpoints
    .filter(c => c.project_id === commitment.project_id)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];

  const ai = getGeminiClient();
  let generatedPlan = '';

  if (ai) {
    try {
      const prompt = `
        As the Chronos Pilot AI Engine, synthesize an achievable, daily step-by-step catch-up schedule for the project: "${project?.project_name}".
        The commitment is due on: ${commitment.deadline_date}.
        The simulated current date is: ${simulatedCurrentTime}.
        
        The developer is currently blocked on:
        "${latestCheckpoint?.blocked_text || 'None reported'}"
        
        The list of uncompleted tasks (actions) is:
        ${actions.map(a => `- ${a.action_text} (Estimated: ${a.estimated_effort_hours} hours)`).join('\n')}
        
        Synthesize an extremely high-fidelity recovery checklist broken down by days (e.g. "[Today]", "[Tomorrow]", etc.) mapping remaining hours. Maximize human motivation and be highly precise. Return a raw JSON array containing tasks, with each item containing: "day" (string) and "task" (string) and "hours" (number). No markdown code block wraps, just valid json array.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      generatedPlan = response.text || '';
    } catch (e) {
      console.error('Error generating plan with Gemini:', e);
    }
  }

  // Fallback scheduling heuristic in case API key is missing or calls fail
  if (!generatedPlan) {
    const fallbackList = actions.map((a, index) => {
      const dayLabel = index === 0 ? '[Today]' : index === 1 ? '[Tomorrow]' : `[Day ${index + 1}]`;
      return {
        day: dayLabel,
        task: a.action_text,
        hours: a.estimated_effort_hours
      };
    });
    generatedPlan = JSON.stringify(fallbackList);
  }

  // Save the recovery plan to database
  const planItem = {
    id: db.recoveryPlans.length + 1,
    commitment_id: commitment.id,
    plan_payload_json: generatedPlan,
    generated_at: simulatedCurrentTime
  };

  db.recoveryPlans.push(planItem);
  db.save();

  res.json({ success: true, plan: planItem });
});

// 9. Reconstruct Workspace State & Generate "Why You Stopped" Diagnostics Card
app.post('/api/workspace/restore', async (req, res) => {
  const { project_id } = req.body;
  const project = db.projects.find(p => p.id === parseInt(project_id));
  if (!project) {
    return res.status(404).json({ error: 'Project not found.' });
  }

  const snapshot = db.workspaceSnapshots.find(s => s.project_id === project.id);
  const latestCheckpoint = db.projectCheckpoints
    .filter(c => c.project_id === project.id)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];

  const searchHistory = db.searchQueries.slice(-3); // mock last searches

  // Generate Cognitive Flow narrative summary via Gemini
  const ai = getGeminiClient();
  let summaryNarrative = '';

  if (ai) {
    try {
      const prompt = `
        The user wants to resume work on "${project.project_name}".
        Their last active file was: "${snapshot?.active_file_path || 'unknown'}" (at line ${snapshot?.cursor_line || 1}).
        They stopped working because of this blocker:
        "${latestCheckpoint?.blocked_text || 'No explicit blocker reported'}"
        
        Their last active web searches were:
        ${searchHistory.map(s => `- ${s.query_text}`).join('\n')}

        Write a short, highly scannable, and extremely polished "Why You Stopped" summary in 3-4 bullet points. Include precise code citations (e.g., file paths, line numbers) and a highly supportive, action-oriented tone. Highlight the exact mental thread they need to pick up. Max 150 words.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt
      });
      summaryNarrative = response.text || '';
    } catch (e) {
      console.error('Error generating workspace restore summary:', e);
    }
  }

  if (!summaryNarrative) {
    // Elegant fallback summary
    summaryNarrative = `
      You paused work on this project 3 days ago:
      • **Mental Thread**: You were working in \`${snapshot?.active_file_path || 'codebase'}\` at line ${snapshot?.cursor_line || 42}.
      • **Active Blocker**: ${latestCheckpoint?.blocked_text || 'No explicit blocker.'}
      • **Last Context**: You searched documentation for "${searchHistory[0]?.query_text || 'stripe local signature test'}".
      • **Pick up at**: Start by resolving offline webhook verification signatures.
    `;
  }

  // Record a virtual RESTORE event to context node to show interaction graph growth!
  const node = db.contextNodes.find(n => n.entity_key.includes(snapshot?.active_file_path || ''));
  if (node) {
    db.contextEvents.push({
      id: db.contextEvents.length + 1,
      node_id: node.id,
      event_type: 'OPENED',
      interaction_duration: 60,
      captured_at: simulatedCurrentTime
    });
    db.save();
  }

  res.json({
    success: true,
    snapshot,
    why_stopped_narrative: summaryNarrative,
    message: `Restored environment: Opened workspace folder, loaded tabs, positioned cursor, and reconstructed search session.`
  });
});

// 10. Simulate Dynamic Telemetry Event Inputs (Demo Scene triggers)
app.post('/api/sandbox/simulate', (req, res) => {
  const { event_type, payload } = req.body;

  if (event_type === 'DOWNLOAD_PDF') {
    // Ingestion of a coursework PDF
    const newFileNode = {
      id: db.contextNodes.length + 1,
      project_id: 1,
      entity_key: `FILE:downloads/${payload.filename}`,
      entity_type: 'DOCUMENT' as const,
      display_name: payload.filename,
      created_at: simulatedCurrentTime
    };

    db.contextNodes.push(newFileNode);

    // CDE: Commitment Discovery Engine analyzes PDF text and creates a commitment!
    const newCommitment = {
      id: db.commitments.length + 1,
      project_id: 1,
      title: 'ML Theoretical Foundations Assignment',
      commitment_type: 'ASSIGNMENT' as const,
      deadline_date: '2026-07-20T23:59:59Z',
      confidence_score: 0.94,
      source_node_id: newFileNode.id,
      status: 'OPEN' as const,
      created_at: simulatedCurrentTime
    };

    db.commitments.push(newCommitment);

    // Create an uncompleted task parsed from the document
    db.projectActions.push({
      id: db.projectActions.length + 1,
      project_id: 1,
      action_text: 'Complete ML math calculations section',
      estimated_effort_hours: 4.5,
      status: 'PENDING',
      priority_score: 0.0,
      created_at: simulatedCurrentTime
    });

    db.save();
    return res.json({
      success: true,
      discovered_commitment: newCommitment,
      discovered_node: newFileNode,
      message: `CDE processed document: Discovered commitment: 'ML Theoretical Foundations' due July 20 (Conf: 94%)`
    });
  }

  if (event_type === 'BROWSER_SEARCH') {
    // Browser telemetry captures search inputs
    const newSession = {
      id: db.browserSessions.length + 1,
      project_id: 1,
      url: `https://www.google.com/search?q=${encodeURIComponent(payload.query)}`,
      page_title: `Google Search: ${payload.query}`,
      domain: 'google.com',
      visit_started_at: simulatedCurrentTime,
      visit_ended_at: simulatedCurrentTime,
      active_seconds: 45,
      created_at: simulatedCurrentTime
    };

    db.browserSessions.push(newSession);

    db.searchQueries.push({
      id: db.searchQueries.length + 1,
      browser_session_id: newSession.id,
      query_text: payload.query,
      created_at: simulatedCurrentTime
    });

    // Also add url node and graph edge to represent semantic graph connection!
    const urlNode = {
      id: db.contextNodes.length + 1,
      project_id: 1,
      entity_key: `URL:search?q=${payload.query}`,
      entity_type: 'URL' as const,
      display_name: `Google Search: "${payload.query}"`,
      created_at: simulatedCurrentTime
    };

    db.contextNodes.push(urlNode);

    // Create graph edge between main file and this search
    db.graphEdges.push({
      source_node_id: 1, // notebook
      target_node_id: urlNode.id,
      edge_type: 'REFERENCES',
      weight: 1.2,
      created_at: simulatedCurrentTime
    });

    db.save();
    return res.json({
      success: true,
      message: `Browser Telemetry tracked search query: "${payload.query}" | Dynamic Graph Edge generated.`
    });
  }

  res.status(400).json({ error: 'Unknown sandbox event type' });
});

// 11. Autonomous Research Companion (ARC) Briefing Feed
app.get('/api/arc/briefs', (req, res) => {
  // Simulating research papers parsed while user was away
  const briefs = [
    {
      id: 1,
      title: 'Optimal Chunking Strategies for RAG Pipelines',
      source: 'arXiv:2403.11024',
      similarity: '94% Semantic Match',
      summary: 'Establishes a baseline for multi-vector document splitting. Suggests recursive token splitters combined with overlap padding (+18% retrieval recall improvement).',
      link: 'https://arxiv.org/abs/2403.11024'
    },
    {
      id: 2,
      title: 'Stripe Webhooks Signature Mock Testing in Offline Node environments',
      source: 'Stripe Developers Community',
      similarity: '89% Semantic Match',
      summary: 'Details how to generate mock Stripe signature headers locally by using the Stripe API library to sign custom test payloads with the endpoint webhook secret.',
      link: 'https://docs.stripe.com/webhooks/signatures'
    }
  ];
  res.json(briefs);
});

// 12. Complete Privacy Inspect / SQL database table views
app.get('/api/database', (req, res) => {
  res.json({
    projects: db.projects,
    projectState: db.projectState,
    contextNodes: db.contextNodes,
    contextEvents: db.contextEvents,
    browserSessions: db.browserSessions,
    searchQueries: db.searchQueries,
    commitments: db.commitments,
    projectDeadlines: db.projectDeadlines,
    projectActions: db.projectActions,
    projectCheckpoints: db.projectCheckpoints,
    recoveryPlans: db.recoveryPlans,
    autonomousResearchBriefs: db.autonomousResearchBriefs,
    graphEdges: db.graphEdges,
    workspaceSnapshots: db.workspaceSnapshots,
    deadLetterQueue: db.deadLetterQueue
  });
});

// 13. System Wipe / Total Reset (Absolute Sovereignty guarantee)
app.post('/api/database/purge', (req, res) => {
  db.projects = [];
  db.projectState = [];
  db.contextNodes = [];
  db.contextEvents = [];
  db.browserSessions = [];
  db.searchQueries = [];
  db.commitments = [];
  db.projectDeadlines = [];
  db.projectActions = [];
  db.projectCheckpoints = [];
  db.recoveryPlans = [];
  db.autonomousResearchBriefs = [];
  db.graphEdges = [];
  db.workspaceSnapshots = [];
  db.deadLetterQueue = [];

  // Seed baseline to avoid blank screen
  db.seedInitialData();

  // Reset clock
  simulatedCurrentTime = '2026-06-23T10:15:00-07:00';

  db.save();
  res.json({ success: true, message: 'System purged successfully. Factory settings restored.' });
});

// --- VITE MIDDLEWARE CONFIGURATION ---

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Chronos Daemon] Operating System online at http://localhost:${PORT}`);
  });
}

startServer();
